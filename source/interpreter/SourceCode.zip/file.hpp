#pragma once

std::string readFile(const std::string& pFileName);